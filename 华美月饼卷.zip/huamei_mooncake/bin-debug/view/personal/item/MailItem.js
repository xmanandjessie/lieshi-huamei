var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MailItem = (function (_super) {
    __extends(MailItem, _super);
    function MailItem() {
        var _this = _super.call(this) || this;
        _this.txtContent = new egret.TextField();
        _this.txtContent.textColor = 0x565656;
        _this.txtContent.size = 20;
        _this.txtContent.x = 120;
        _this.txtContent.y = 15;
        _this.txtContent.text = "";
        _this.addChild(_this.txtContent);
        _this.txtTime = new egret.TextField();
        _this.txtTime.textColor = 0x565656;
        _this.txtTime.size = 20;
        _this.txtTime.x = 143;
        _this.txtTime.y = 55;
        _this.txtTime.text = "";
        _this.addChild(_this.txtTime);
        var line = new CustomImage("resource/assets/asyn/order/line2.png", true, function () {
            line.width = 410;
            line.x = 135;
            line.y = 90;
        });
        _this.addChild(line);
        return _this;
    }
    MailItem.prototype.setData = function (index, data) {
        if (index == 0) {
            this.txtContent.textColor = 0x002a88;
        }
        else {
            this.txtContent.textColor = 0x565656;
        }
        this.txtContent.text = "●  " + data.address + " " + data.remark;
        this.txtTime.text = data.time + "";
    };
    return MailItem;
}(egret.DisplayObjectContainer));
__reflect(MailItem.prototype, "MailItem");
//# sourceMappingURL=MailItem.js.map