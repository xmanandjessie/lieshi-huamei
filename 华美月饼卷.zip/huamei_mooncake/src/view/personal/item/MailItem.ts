class MailItem extends egret.DisplayObjectContainer
{
	private txtContent:egret.TextField;

	private txtTime:egret.TextField;

	public constructor() 
	{
		super();

		this.txtContent = new egret.TextField();
		this.txtContent.textColor = 0x565656;
		this.txtContent.size = 20;
		this.txtContent.x = 120;
		this.txtContent.y = 15;
		this.txtContent.text = "";
		this.addChild(this.txtContent);

		this.txtTime = new egret.TextField();
		this.txtTime.textColor = 0x565656;
		this.txtTime.size = 20;
		this.txtTime.x = 143;
		this.txtTime.y = 55;
		this.txtTime.text = "";
		this.addChild(this.txtTime);

		var line = new CustomImage("resource/assets/asyn/order/line2.png", true, () => {
			line.width = 410;
			line.x = 135;
			line.y = 90;
		});
		this.addChild(line);
	}

	public setData(index,data):void
	{
		if(index == 0)
		{
			this.txtContent.textColor = 0x002a88;
		}else
		{
			this.txtContent.textColor = 0x565656;
		}
		this.txtContent.text = "●  " + data.address + " "+data.remark;
		this.txtTime.text = data.time + "";
	}
}