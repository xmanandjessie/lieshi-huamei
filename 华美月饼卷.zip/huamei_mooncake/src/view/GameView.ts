class GameView extends egret.DisplayObjectContainer
{
	public constructor()
	{
		super();

		PopManager.showPop("SelectListPop");
	}
}